import Mag from './Mag.vue';
export default Mag;